export const formLabel = {
    numberOfLocalVisitors: "Number of local visitors",
    funding: "Funding for the facility",
    ratings: "Rating for the the facility",
    numberOfForeignVisitors: "Number of foreign visitors",
    // 
    toilet: "Quality of toilet",
    plumbing: "Quality of plumbing",
    accomodation: "Quality of accomodation",
    // 
    staff: "Cooperation of staff",
    authority: "Authority of staff"
}

