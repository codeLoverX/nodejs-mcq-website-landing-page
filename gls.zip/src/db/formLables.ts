export const formLabel = {
    //
    numberOfLocalVisitors: "Does your PTJ develop a disaster prevention plan in collaboration between universities and local entities",
    funding: "UTM's Sustainability Policy must be taken into account in PTJ planning Does PTJ/Office/Unit/Division take into account UTM's sustainability policy",
    ratings: "Does your PTJ provide incentives for living laboratory sustainability initiatives",
    numberOfForeignVisitors: "Does the PTJ provide initiatives for sustainability programs / research and innovation with the community",
    // 
    toilet: "Rate the quality of toilet in your PTJ",
    plumbing: "Rate the quality of plumbing in your PTJ",
    accomodation: "Rate the quality of accomodation in your PTJ",
    // 
    staff: "Rate the quality of furniture in your PTJ",
    authority: "Rate the quality of furnishings (ceilings/floor/paint) in your PTJ"
}

