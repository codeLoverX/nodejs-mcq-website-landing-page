class Competition {

	description: string;
	endDate: Date;
	invitation: string;
	programID: string;
	programName: string;
	startDate: Date;
	
	constructor(){}

	

}//end Competition

