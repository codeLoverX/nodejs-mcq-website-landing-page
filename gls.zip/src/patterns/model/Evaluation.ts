class Evaluation {

	applicationID: string;
	evaluationDateTime: string;
	judgeID: string;
	markEachElements: Array<number>;
	rank: number;
	result: string;
	TotalMark: number;

}//end Evaluation

