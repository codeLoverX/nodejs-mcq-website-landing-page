class Judge {

	email: string;
	judjeID: string;
	name: string;
}//end Judge

