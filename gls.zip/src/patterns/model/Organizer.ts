class Organizer {

	address: string;
	contact: string;
	email: string;
	fullName: string;
	organizerID: string;
	organizerPosition: string;
	
}//end Organizer

