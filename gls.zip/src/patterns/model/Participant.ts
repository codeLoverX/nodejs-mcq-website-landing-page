class Participant {

	fName: string;
	lName: string;
	PTJType: string;
	staffAddress: string;
	StaffEmail: string;
	staffID: string;
	StaffPhoneNo: string;
	
	// this.m_Application=null;

}//end Participant

