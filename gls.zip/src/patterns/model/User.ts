class User {
	passWord: string;
	signInStatus: string;
	signUpStatus: string;
	userName: string;
}//end User
